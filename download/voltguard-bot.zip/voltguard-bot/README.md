# Voltguard — Bot Discord + Pannello Admin

Bot di sicurezza per Discord reale e funzionante, con pannello admin web per gestirlo.
Copre tutte le funzionalità promesse sul sito: **anti-raid intelligente, filtro anti-spam,
verifica utenti, auto-moderazione (con IA opzionale), log in tempo reale, backup automatico
di ruoli/canali, gestione multi-server e API per regole personalizzate (piano Enterprise)**.

## Come funziona

Questo è un bot **self-hosted**: lo fai girare tu, con il tuo token Discord. Ci sono due processi:

1. **Il bot** (`src/bot`) — si connette a Discord e applica anti-raid, anti-spam, automod, verifica, backup.
2. **Il pannello admin** (`src/admin`) — un sito web dove chi ha "Gestisci server" su Discord
   può fare login e configurare tutto senza usare comandi.

I due processi condividono lo stesso database SQLite (`data/voltguard.sqlite`), quindi le modifiche
fatte nel pannello si riflettono subito nel bot, e viceversa.

## 1. Crea l'applicazione Discord

1. Vai su [discord.com/developers/applications](https://discord.com/developers/applications) → **New Application**.
2. Sezione **Bot** → **Reset Token** → copia il token (`DISCORD_TOKEN`).
3. Attiva questi **Privileged Gateway Intents**: `Server Members Intent`, `Message Content Intent`.
4. Sezione **General Information** → copia **Application ID** (`DISCORD_CLIENT_ID`) e **Client Secret** (`DISCORD_CLIENT_SECRET`).
5. Sezione **OAuth2 → General** → in **Redirects** aggiungi: `http://localhost:3000/auth/callback`
   (o l'URL reale del tuo pannello admin in produzione).

## 2. Genera il link di invito del bot

In **OAuth2 → URL Generator**, seleziona lo scope `bot` e i permessi minimi:
`Manage Roles`, `Kick Members`, `Ban Members`, `Moderate Members`, `Manage Channels`,
`View Channels`, `Send Messages`, `Manage Messages`, `Read Message History`.
Copia l'URL generato: è il link "Aggiungi a Discord" da mettere sul sito (vedi sotto).

## 3. Installazione

```bash
npm install
cp .env.example .env
# apri .env e incolla i valori ottenuti sopra
```

## 4. Registra gli slash command

```bash
npm run deploy-commands
```

Va rieseguito solo quando aggiungi/modifichi comandi (non ad ogni avvio).

## 5. Avvio

```bash
# avvia bot + pannello admin insieme
npm run start:all

# oppure separatamente, in due terminali
npm start            # solo il bot
npm run start:admin  # solo il pannello admin (di default su http://localhost:3000)
```

Al primo avvio, apri `http://localhost:3000`, fai login con Discord: vedrai i server dove hai
il permesso "Gestisci server" **e** dove Voltguard è già presente.

## Comandi disponibili nel bot

| Comando | Descrizione |
|---|---|
| `/voltguard-setup` | Configura canale log, canale/ruolo verifica, ruolo quarantena, ruoli protetti |
| `/antiraid` | Configura soglie e azione anti-raid |
| `/antispam` | Configura soglie e azione anti-spam |
| `/automod` | Gestisce parole bloccate, blocco invite, controllo IA |
| `/verify-panel` | Pubblica il pannello con il bottone di verifica |
| `/kick`, `/ban` | Moderazione manuale |
| `/quarantine`, `/unquarantine` | Mette/rimuove un utente dalla quarantena |
| `/backup crea|lista|ripristina` | Backup e ripristino struttura server |
| `/stats` | Statistiche di sicurezza del server |
| `/apikey` | Genera una API key (piano Enterprise) |

Tutte queste impostazioni sono modificabili anche dal pannello admin, senza usare comandi.

## Piani (Free / Pro / Enterprise)

Il campo `plan` in `guild_settings` determina cosa è sbloccato (es. controllo IA e API sono
riservati a Pro/Enterprise). Di default ogni nuovo server è sul piano `free`. Per cambiare piano
manualmente:

```bash
sqlite3 data/voltguard.sqlite "UPDATE guild_settings SET plan='pro' WHERE guild_id='ID_DEL_SERVER';"
```

Se in futuro vuoi automatizzare l'upgrade dopo un pagamento PayPal reale, collega il webhook
PayPal a un piccolo endpoint che esegue questo stesso update (non incluso qui perché richiede
le tue credenziali PayPal live).

## Deploy in produzione

- Bot e pannello possono girare sullo stesso VPS (es. con `pm2` o `systemd`) o su due servizi
  separati (es. Railway, Fly.io, un droplet Hetzner/DigitalOcean).
- Ricorda di aggiornare `ADMIN_BASE_URL` in `.env` e il Redirect URI su Discord con l'URL reale.
- Il file `data/voltguard.sqlite` contiene tutte le configurazioni: fanne backup regolarmente.

## Collegare il download al sito

Nella cartella del sito, il bottone/sezione "Scarica il bot" punta a `download/voltguard-bot.zip`,
che contiene questo intero progetto pronto per essere scompattato e configurato come sopra.
